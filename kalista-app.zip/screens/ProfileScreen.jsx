import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Alert,
  TouchableOpacity,
  ScrollView,
  Platform,
} from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function ProfileScreen() {
  const [profile, setProfile] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const [datePickerKey, setDatePickerKey] = useState(null);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const stored = await AsyncStorage.getItem("@user_profile");
        if (stored) {
          setProfile(JSON.parse(stored));
        }
      } catch (e) {
        console.log("❌ Gagal muat profil:", e);
      }
    };
    loadProfile();
  }, []);

  const handleChange = (key, value) => {
    setProfile({ ...profile, [key]: value });
  };

  const handleSave = async () => {
    try {
      await AsyncStorage.setItem("@user_profile", JSON.stringify(profile));
      setIsEditing(false);
      Alert.alert("✅ Berhasil", "Profil berhasil disimpan");
    } catch (e) {
      console.log("❌ Gagal simpan profil:", e);
    }
  };

  const openDatePicker = (key) => {
    setDatePickerKey(key);
  };

  const onDateChange = (event, selectedDate) => {
    if (selectedDate && datePickerKey) {
      const iso = selectedDate.toISOString();
      handleChange(datePickerKey, iso);
    }
    setDatePickerKey(null);
  };

  const renderField = (label, key, isDate = false) => {
    const value = profile[key];
    const isDateField = isDate && isEditing;

    return (
      <View style={styles.field}>
        <Text style={styles.label}>{label}</Text>
        {isEditing ? (
          isDateField ? (
            <TouchableOpacity
              onPress={() => openDatePicker(key)}
              style={styles.dateButton}
            >
              <Text>
                {value
                  ? new Intl.DateTimeFormat("id-ID", {
                      day: "numeric",
                      month: "long",
                      year: "numeric",
                    }).format(new Date(value))
                  : "Pilih Tanggal"}
              </Text>
            </TouchableOpacity>
          ) : (
            <TextInput
              style={styles.input}
              value={value ? String(value) : ""}
              onChangeText={(text) => handleChange(key, text)}
            />
          )
        ) : (
          <Text style={styles.value}>
            {isDate && value
              ? new Intl.DateTimeFormat("id-ID", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                }).format(new Date(value))
              : value || "-"}
          </Text>
        )}
      </View>
    );
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <Text style={styles.title}>Profil Pengguna</Text>

      {renderField("Nama", "name")}
      {renderField("Status", "status")}
      {renderField("Tanggal Lahir", "birthDate", true)}
      {renderField("Memiliki Anak", "hasChild")}
      {renderField("Haid Terakhir", "lastPeriod", true)}
      {renderField("HPL", "hpl", true)}

      {datePickerKey && (
        <DateTimePicker
          mode="date"
          value={
            profile[datePickerKey]
              ? new Date(profile[datePickerKey])
              : new Date()
          }
          display={Platform.OS === "ios" ? "spinner" : "default"}
          onChange={onDateChange}
        />
      )}

      <View style={{ marginTop: 20 }}>
        {isEditing ? (
          <TouchableOpacity style={styles.button} onPress={handleSave}>
            <Text style={styles.buttonText}>Simpan</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={styles.button}
            onPress={() => setIsEditing(true)}
          >
            <Text style={styles.buttonText}>Edit Profil</Text>
          </TouchableOpacity>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    padding: 24,
    backgroundColor: "#fffafc",
    paddingBottom: 100,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#fe61ad",
    marginBottom: 24,
    textAlign: "center",
  },
  field: {
    marginBottom: 16,
    backgroundColor: "#fff0f5",
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#fe61ad20",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    color: "#444",
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: "#fe61ad50",
    padding: 10,
    borderRadius: 8,
    backgroundColor: "#fff",
    fontSize: 15,
  },
  dateButton: {
    padding: 10,
    backgroundColor: "#fff",
    borderColor: "#fe61ad30",
    borderWidth: 1,
    borderRadius: 8,
  },
  value: {
    fontSize: 15,
    color: "#333",
  },
  button: {
    backgroundColor: "#fe61ad",
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});
